/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project1;

import java.util.Collection;
import java.util.Iterator;
import java.util.ListIterator;

/**
 *
 * @author viniciuscustodio
 */
public class List {

    public int find() {
        return 0;
    }
    
    public int size() {
        return 0;
    }

    public int contains(){
        return 0;
    }
    
    public void remove(Object ob){
    
    }
    
    public void add (Object ob){
        
    }
    
    public void get(int index){
    
    }
    
    public void getNext(){
        
    }
    
    public void reset(){
    
    }
   
    @Override
    public String toString(){
        return "Sim";
    }
}
